let sld1 = document.getElementsByClassName("slide1");
let sld2 = document.getElementsByClassName("slide2");
let sld3 = document.getElementsByClassName("slide3");


sld1[0].addEventListener("click", function(){
    window.location.href = "slide1.html";
});

sld2[0].addEventListener("click", function(){
    window.location.href = "slide2.html";
});

sld3[0].addEventListener("click", function(){
    window.location.href = "slide3.html";
});




