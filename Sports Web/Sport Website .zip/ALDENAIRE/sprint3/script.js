// Get all the card elements
const cards = document.querySelectorAll('.card');

// Loop through each card and add event listeners for hover effect
cards.forEach(card => {
    card.addEventListener('mouseenter', () => {
        // Add 'focused' class to the hovered card
        card.classList.add('focused');
        // Add 'blurred' class to the other cards
        cards.forEach(otherCard => {
            if (otherCard !== card) {
                otherCard.classList.add('blurred');
            }
        });
    });
    card.addEventListener('mouseleave', () => {
        // Remove 'focused' class from the hovered card
        card.classList.remove('focused');
        // Remove 'blurred' class from the other cards
        cards.forEach(otherCard => {
            if (otherCard !== card) {
                otherCard.classList.remove('blurred');
            }
        });
    });
});
